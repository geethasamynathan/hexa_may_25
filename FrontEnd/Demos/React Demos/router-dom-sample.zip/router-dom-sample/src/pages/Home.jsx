function Home() {
	return (
	  <div>
		<h1>Welcome to Our Hospital</h1>
		<p>This is the Landing Page for User</p>
	  </div>
	);
  }
  
  export default Home;