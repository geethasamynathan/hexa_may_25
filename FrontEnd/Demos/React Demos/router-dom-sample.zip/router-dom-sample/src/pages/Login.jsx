import { useState } from "react"
import { useAuth } from "../auth/AuthContext";
import { replace,useNavigate } from "react-router-dom";

 function Login(){
	const navigate=useNavigate();
	const {login} = useAuth();
	const [formdata , setFormData] = useState({username:'',
		password:''
	});
	const [error,setError] = useState("");
	
	const handelSubmit = (e)=>{
       e.PreventDefault();
       const result = login(formdata);
	   if(!result.ok)
		{ setError(result.message)
			return;
		}
		const routesByRole = {
			doctor : "/doctor-dashboard",
			user : "/user-dashboard"
		};
		navigate(routesByRole[result.role]??"/dashboard",{replace:true})
	}

	const handleChange = (e)=>{
     setFormData({...formdata,[e.target.name]:e.target.value})
	}

	return(
		<>
		<div className="container">
		<h2>Login form</h2>
		<form action="handleSubmit">
			<div className="form-group">
			<label className="form-lable">Username:</label>
			<input type="text" id="username" name="username" onChange={handleChange} required className="form-control" value={formdata.username}/>
			</div>
			<div className="form-group">
			<label className="form-lable">Passwrod:</label>
			<input type="text" id="password" name="password" required onChange={handleChange}  className="form-control" value={formdata.password}/>
			</div>
			<button className="btn btn-primary" type="submit">login!</button>


		</form>
		</div>
		</>
	)
}

export default Login;